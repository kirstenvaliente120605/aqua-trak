ALTER TABLE `stations`
  ADD COLUMN `status` VARCHAR(32) NOT NULL DEFAULT 'open';

<?php
/** Local Brevo diagnostic. Never expose this endpoint to remote clients. */

declare(strict_types=1);

$remoteAddress = $_SERVER['REMOTE_ADDR'] ?? '';
if (!in_array($remoteAddress, ['127.0.0.1', '::1'], true)) {
    http_response_code(403);
    exit('Forbidden: this email diagnostic is available only from localhost.');
}

header('Content-Type: text/plain; charset=utf-8');

if (($_GET['env'] ?? '') === '1') {
    $apiKey = (string) (getenv('BREVO_API_KEY') ?: '');
    $senderEmail = (string) (getenv('BREVO_SENDER_EMAIL') ?: '');
    $hasSurroundingQuotes = static function (string $value): bool {
        $length = strlen($value);
        return $length >= 2
            && (($value[0] === '"' && $value[$length - 1] === '"')
                || ($value[0] === "'" && $value[$length - 1] === "'"));
    };

    echo 'BREVO_API_KEY configured: ' . ($apiKey !== '' ? 'yes' : 'no') . "\n";
    echo 'BREVO_API_KEY has edge whitespace: ' . ($apiKey !== trim($apiKey) ? 'yes' : 'no') . "\n";
    echo 'BREVO_API_KEY has surrounding quotes: ' . ($hasSurroundingQuotes($apiKey) ? 'yes' : 'no') . "\n";
    echo 'BREVO_SENDER_EMAIL configured: ' . (trim($senderEmail) !== '' ? 'yes' : 'no') . "\n";
    echo 'BREVO_SENDER_EMAIL: ' . $senderEmail . "\n";
    echo 'BREVO_SENDER_EMAIL has edge whitespace: ' . ($senderEmail !== trim($senderEmail) ? 'yes' : 'no') . "\n";
    echo 'BREVO_SENDER_EMAIL has surrounding quotes: ' . ($hasSurroundingQuotes($senderEmail) ? 'yes' : 'no') . "\n";
    exit;
}

$recipient = filter_input(INPUT_GET, 'email', FILTER_VALIDATE_EMAIL);
if (!is_string($recipient) || $recipient === '') {
    http_response_code(400);
    exit('Provide a valid recipient address, for example ?email=test@example.com');
}

require_once dirname(__DIR__) . '/mailer.php';

try {
    \AquaTracker\sendOtpEmail([
        'to' => $recipient,
        'code' => '000000',
        'purpose' => 'verify_email',
    ]);
    echo "Success: Brevo accepted the diagnostic verification email for delivery.\n";
} catch (\Throwable $error) {
    http_response_code(502);
    echo "Brevo email test failed. Check the server-side error log.\n";
}

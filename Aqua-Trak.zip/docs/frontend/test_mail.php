<?php
// Apache serves frontend/ as its document root; preserve this public URL and
// forward it to the guarded diagnostic implementation under backend/.
require dirname(__DIR__) . '/backend/api/diagnostics/test_mail.php';

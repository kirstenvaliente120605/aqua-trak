-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: aquatracker
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer` (
  `id` char(36) NOT NULL,
  `user_id` char(36) DEFAULT NULL,
  `aqua_points` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `customer_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES ('01aadc1b-7acf-401f-b656-88b931babdae','USR_031',0),('1f99dfe5-a1c5-4380-a62b-31f4a44e9d30','USR_028',0),('23ed4252-3f2c-4818-b27c-4be730dd62ad','USR_029',0),('299f8215-338a-49d4-9756-05fc9eaa4586','USR_004',0),('2a627c10-44be-47d1-bbc7-f99cec0820b0','USR_026',0),('3b96fd73-9158-4d7f-a2ee-163a093df79f','USR_018',0),('4b765f94-f5ba-4bb0-a0ca-50463df868b4','USR_001',0),('6d5d8c81-ca32-4c27-b551-74f2d072588a','USR_006',20),('8504e47f-7667-4b5b-9751-c8ad120153b6','USR_016',0),('8fa51d18-1324-4348-9441-d19407c56075','USR_027',0),('93861445-7a3a-432c-95b1-7b789cf9bd99','USR_035',0),('affe8403-0267-4453-889d-aa59dd52f29d','USR_017',0),('cus-demo-001','USR_009',240),('d31e9a53-3d84-46fa-9c7c-115a5528daf9','USR_030',0),('dc702a40-2b0c-4205-a33d-95f05de6bfc6','USR_020',0),('dcb3ad46-279f-4903-b4fe-112d60be39ed','USR_019',0),('e37087e4-e74f-4207-8f9e-567b4bd12769','USR_021',0),('f231a3e1-b96f-47b8-9d59-0acae6f0a9f6','USR_025',0),('f6f612f5-1da7-4c0d-9ec3-e6427858a078','USR_005',0);
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_reward`
--

DROP TABLE IF EXISTS `customer_reward`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_reward` (
  `id` char(36) NOT NULL,
  `customer_id` char(36) DEFAULT NULL,
  `reward_id` char(36) DEFAULT NULL,
  `points` int(11) DEFAULT NULL,
  `earned_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`),
  KEY `reward_id` (`reward_id`),
  CONSTRAINT `customer_reward_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`),
  CONSTRAINT `customer_reward_ibfk_2` FOREIGN KEY (`reward_id`) REFERENCES `reward` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_reward`
--

LOCK TABLES `customer_reward` WRITE;
/*!40000 ALTER TABLE `customer_reward` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_reward` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_otps`
--

DROP TABLE IF EXISTS `email_otps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `email_otps` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(190) NOT NULL,
  `user_id` char(36) NOT NULL,
  `code_hash` varchar(255) NOT NULL,
  `purpose` enum('verify_email','reset_password') NOT NULL,
  `expires_at` datetime NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `used_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_email_otps_email_purpose` (`email`,`purpose`,`id`),
  KEY `ix_email_otps_expiry` (`expires_at`),
  KEY `fk_email_otps_user` (`user_id`),
  CONSTRAINT `fk_email_otps_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_otps`
--

LOCK TABLES `email_otps` WRITE;
/*!40000 ALTER TABLE `email_otps` DISABLE KEYS */;
INSERT INTO `email_otps` VALUES (1,'villaricojerryson@gmail.com','USR_020','$2y$10$wGek/ap4Iu86Yl8pCH0Q0u.m6FYdJYu0M03lDG6.TRCFADhlhGwmu','reset_password','2026-11-13 09:57:24',0,'2026-11-13 09:47:24','2026-11-13 09:47:41'),(2,'klintrant@gmail.com','USR_031','$2y$10$I8DZNTwrK9vCzpoP73jR9.HYQlfZ6OELcEoFVQStUFtW4RzoX6HZ.','verify_email','2026-11-13 09:58:49',0,'2026-11-13 09:48:49','2026-11-13 09:49:08'),(3,'percyvaliente500@gmail.com','USR_035','$2y$10$50m1/UuFm2Ljk4obYBhoPONhDaYCmuOVfwLIncqgDJweUIA.UEEe.','verify_email','2026-11-14 12:15:49',0,'2026-11-14 12:05:49','2026-11-14 12:06:16');
/*!40000 ALTER TABLE `email_otps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `id_sequence`
--

DROP TABLE IF EXISTS `id_sequence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `id_sequence` (
  `name` varchar(32) NOT NULL,
  `value` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `id_sequence`
--

LOCK TABLES `id_sequence` WRITE;
/*!40000 ALTER TABLE `id_sequence` DISABLE KEYS */;
INSERT INTO `id_sequence` VALUES ('owners',8),('stations',12),('users',36);
/*!40000 ALTER TABLE `id_sequence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification`
--

DROP TABLE IF EXISTS `notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notification` (
  `id` char(36) NOT NULL,
  `user_id` char(36) DEFAULT NULL,
  `title` varchar(190) DEFAULT NULL,
  `body` text DEFAULT NULL,
  `read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `notification_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification`
--

LOCK TABLES `notification` WRITE;
/*!40000 ALTER TABLE `notification` DISABLE KEYS */;
INSERT INTO `notification` VALUES ('0fd68092-09e4-4ef3-8a78-33f998ee9474','USR_006','Order placed','Your delivery order from DRINK n\' REFILL Purified Water Refilling Station was received. You earned +20 AquaPoints.',0,'2026-10-27 15:20:55');
/*!40000 ALTER TABLE `notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order`
--

DROP TABLE IF EXISTS `order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order` (
  `id` char(36) NOT NULL,
  `customer_id` char(36) DEFAULT NULL,
  `station_id` char(36) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `meta` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`meta`)),
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`),
  KEY `station_id` (`station_id`),
  CONSTRAINT `order_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`),
  CONSTRAINT `order_ibfk_2` FOREIGN KEY (`station_id`) REFERENCES `station` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order`
--

LOCK TABLES `order` WRITE;
/*!40000 ALTER TABLE `order` DISABLE KEYS */;
INSERT INTO `order` VALUES ('c5f956fe-79e2-4fbe-b8bb-4fa0a5cba789','6d5d8c81-ca32-4c27-b551-74f2d072588a','STN_002','delivery','pending',55.00,'2026-10-27 15:20:55','{\"stationName\":\"DRINK n\' REFILL Purified Water Refilling Station\",\"stationAddress\":\"45 Sabellano St, San Jose District, Pagadian City\",\"customerName\":\"Emmanuel Geroche\",\"items\":[{\"productId\":\"drink-refill:5-gal-slim\",\"type\":\"5-gal-slim\",\"label\":\"5-Gallon Slim\",\"qty\":2,\"unitPrice\":35}],\"gallonsTotal\":2,\"fulfillmentType\":\"delivery\",\"deliveryAddress\":\"Block 4, Lot 12, Sunrise Village, Brgy. San Jose\",\"landmark\":\"Near Yellow Chapel\",\"contactPhone\":\"+63 917 555 4321\",\"notes\":\"\",\"paymentMethod\":\"Cash on Delivery\",\"paymentStatus\":\"paid\",\"subtotal\":70,\"discount\":30,\"deliveryFee\":15,\"pointsEarned\":20}');
/*!40000 ALTER TABLE `order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_item`
--

DROP TABLE IF EXISTS `order_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_item` (
  `id` char(36) NOT NULL,
  `order_id` char(36) DEFAULT NULL,
  `product_id` char(36) DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `unit_price` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `order_item_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `order` (`id`),
  CONSTRAINT `order_item_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_item`
--

LOCK TABLES `order_item` WRITE;
/*!40000 ALTER TABLE `order_item` DISABLE KEYS */;
INSERT INTO `order_item` VALUES ('5b0fa6d6-c877-4ef1-b45e-6e2397a49e5b','c5f956fe-79e2-4fbe-b8bb-4fa0a5cba789','drink-refill:5-gal-slim',2,35.00);
/*!40000 ALTER TABLE `order_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `otp_rate_limits`
--

DROP TABLE IF EXISTS `otp_rate_limits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `otp_rate_limits` (
  `scope` varchar(8) NOT NULL,
  `key_hash` char(64) NOT NULL,
  `action` varchar(32) NOT NULL,
  `window_started_at` datetime NOT NULL,
  `request_count` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`scope`,`key_hash`,`action`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `otp_rate_limits`
--

LOCK TABLES `otp_rate_limits` WRITE;
/*!40000 ALTER TABLE `otp_rate_limits` DISABLE KEYS */;
INSERT INTO `otp_rate_limits` VALUES ('email','00b7fd89402a6d76a8bab5d9db9df6a004bec412b992932ba6ec0a42cb3bc124','send:reset_password','2026-11-13 09:47:24',1),('email','00b7fd89402a6d76a8bab5d9db9df6a004bec412b992932ba6ec0a42cb3bc124','verify:reset_password','2026-11-13 09:47:41',1),('email','55d4537e06b7c06bbbfea6d0788462f1d5509eb23fcb341b58a7dc45a15a7774','send:reset_password','2026-11-12 21:29:24',3),('email','5e1ac59f7a44a34355c514d6888c736a76f4643076aa2b22d9dd1dc8b3d08ddb','send:verify_email','2026-11-14 12:05:48',1),('email','5e1ac59f7a44a34355c514d6888c736a76f4643076aa2b22d9dd1dc8b3d08ddb','verify:verify_email','2026-11-14 12:06:16',1),('email','6021a3d773cdbf04e4917e6f23ee5ebc0172d1d9cc6c2fdd003b8c000ae75997','send:reset_password','2026-11-12 21:30:35',1),('email','665b75c60837e83c40367f79517041582136eecab0e36a4428321b61be06b425','send:reset_password','2026-11-12 21:33:27',1),('email','bc15dc1771452b08027ef1e4ce00405e0fdce72e44e10c47f05d859407165ee5','send:verify_email','2026-11-13 09:48:49',1),('email','bc15dc1771452b08027ef1e4ce00405e0fdce72e44e10c47f05d859407165ee5','verify:verify_email','2026-11-13 09:49:08',1),('ip','12ca17b49af2289436f303e0166030a21e525d266e209267433801a8fd4071a0','send:reset_password','2026-11-13 09:47:24',1),('ip','12ca17b49af2289436f303e0166030a21e525d266e209267433801a8fd4071a0','send:verify_email','2026-11-13 09:48:49',1),('ip','12ca17b49af2289436f303e0166030a21e525d266e209267433801a8fd4071a0','verify:reset_password','2026-11-13 09:47:41',1),('ip','12ca17b49af2289436f303e0166030a21e525d266e209267433801a8fd4071a0','verify:verify_email','2026-11-13 09:49:08',1),('ip','eff8e7ca506627fe15dda5e0e512fcaad70b6d520f37cc76597fdb4f2d83a1a3','send:verify_email','2026-11-14 12:05:48',1),('ip','eff8e7ca506627fe15dda5e0e512fcaad70b6d520f37cc76597fdb4f2d83a1a3','verify:verify_email','2026-11-14 12:06:16',1);
/*!40000 ALTER TABLE `otp_rate_limits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_reset_tokens` (
  `token_hash` char(64) NOT NULL,
  `email` varchar(190) NOT NULL,
  `user_id` char(36) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `used_at` datetime DEFAULT NULL,
  PRIMARY KEY (`token_hash`),
  KEY `ix_password_reset_tokens_user` (`user_id`),
  KEY `ix_password_reset_tokens_expiry` (`expires_at`),
  CONSTRAINT `fk_password_reset_tokens_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
INSERT INTO `password_reset_tokens` VALUES ('388f092872489424d634c95dd3fa8da28d11aa2f1a376e883b38bac9ff52f9c2','villaricojerryson@gmail.com','USR_020','2026-11-13 09:57:41','2026-11-13 09:47:41','2026-11-13 09:47:55');
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pricing`
--

DROP TABLE IF EXISTS `pricing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pricing` (
  `id` char(36) NOT NULL,
  `product_id` char(36) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `effective_from` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `pricing_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pricing`
--

LOCK TABLES `pricing` WRITE;
/*!40000 ALTER TABLE `pricing` DISABLE KEYS */;
INSERT INTO `pricing` VALUES ('08a2c62d-0752-4c73-811e-122b6b08dc8f','waterpol:5-gal-round',37.00,'2026-10-27 15:00:25'),('0a6b495b-d787-48e0-ba23-628a4f719555','ultra-pure:5-gal-round',32.00,'2026-10-27 15:00:25'),('0f213ac2-e4f9-439f-b843-6fbb706f16af','drink-refill:5-gal-slim',35.00,'2026-10-27 15:00:25'),('13a790eb-b9b6-434c-a3d0-699b7c96119d','STN_002:2.5-gallon',22.00,'2026-10-31 13:27:12'),('1aa172db-b3af-47d2-b712-7ae2a358dc36','pg-aquamaster:5-gal-round',32.00,'2026-10-27 15:00:25'),('36cec7e9-2e61-4651-b2a2-511d547d8073','STN_002:5-gallon',40.00,'2026-10-31 13:27:12'),('3d57a449-50d4-4eca-9814-8f4d60357e71','ph2o:5-gal-slim',30.00,'2026-10-27 15:00:25'),('69e480f0-d792-4440-9097-aa90b844c47b','drink-refill:5-gal-round',37.00,'2026-10-27 15:00:25'),('77cc512c-9276-4315-9e77-0e6b8856f01e','ultra-pure:5-gal-slim',30.00,'2026-10-27 15:00:25'),('99e794fc-b2c6-40ba-b8af-80017ce4942a','aquater:5-gal-slim',25.00,'2026-10-27 15:00:25'),('a0e8f99f-2fc8-4b73-9c91-cba43bf4b7d2','aquater:5-gal-round',27.00,'2026-10-27 15:00:25'),('a150b286-9e3d-4b55-84a6-9996f6a7df4b','drink-refill:refill',35.00,'2026-10-27 15:01:39'),('f2c3d2b6-127d-4f1a-ad76-f10e45ce54e7','pg-aquamaster:5-gal-slim',30.00,'2026-10-27 15:00:25'),('f46fd811-b6e5-49b5-83e4-35b0cf08b5e0','waterpol:5-gal-slim',35.00,'2026-10-27 15:00:25'),('f545642b-5166-4e8c-980c-00550106fd92','ph2o:5-gal-round',32.00,'2026-10-27 15:00:25');
/*!40000 ALTER TABLE `pricing` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product` (
  `id` char(36) NOT NULL,
  `station_id` char(36) DEFAULT NULL,
  `name` varchar(190) DEFAULT NULL,
  `unit` varchar(50) DEFAULT NULL,
  `stock_qty` int(11) DEFAULT 0,
  `type` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `station_id` (`station_id`),
  CONSTRAINT `product_ibfk_1` FOREIGN KEY (`station_id`) REFERENCES `station` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES ('aquater:5-gal-round','STN_001','5-Gallon Round','refill',0,'5-gal-round'),('aquater:5-gal-slim','STN_001','5-Gallon Slim','refill',0,'5-gal-slim'),('aquater:bottles','STN_001','Refill bottles','bottles',0,'bottles'),('aquater:caps','STN_001','Sanitary caps','caps',0,'caps'),('aquater:seals','STN_001','Bottle seals','seals',0,'seals'),('drink-refill:5-gal-round','STN_002','5-Gallon Round','refill',0,'5-gal-round'),('drink-refill:5-gal-slim','STN_002','5-Gallon Slim','refill',0,'5-gal-slim'),('drink-refill:bottles','STN_002','Refill bottles','bottles',42,'bottles'),('drink-refill:caps','STN_002','Sanitary caps','caps',86,'caps'),('drink-refill:refill','STN_002','refill','refill',0,'refill'),('drink-refill:seals','STN_002','Bottle seals','seals',64,'seals'),('pg-aquamaster:5-gal-round','STN_003','5-Gallon Round','refill',0,'5-gal-round'),('pg-aquamaster:5-gal-slim','STN_003','5-Gallon Slim','refill',0,'5-gal-slim'),('pg-aquamaster:bottles','STN_003','Refill bottles','bottles',0,'bottles'),('pg-aquamaster:caps','STN_003','Sanitary caps','caps',0,'caps'),('pg-aquamaster:seals','STN_003','Bottle seals','seals',0,'seals'),('ph2o:5-gal-round','STN_004','5-Gallon Round','refill',0,'5-gal-round'),('ph2o:5-gal-slim','STN_004','5-Gallon Slim','refill',0,'5-gal-slim'),('ph2o:bottles','STN_004','Refill bottles','bottles',0,'bottles'),('ph2o:caps','STN_004','Sanitary caps','caps',0,'caps'),('ph2o:seals','STN_004','Bottle seals','seals',0,'seals'),('STN_002:2.5-gallon','STN_002','2.5 Gallon','refill',0,'2.5-gallon'),('STN_002:5-gallon','STN_002','5 Gallon','refill',0,'5-gallon'),('ultra-pure:5-gal-round','STN_007','5-Gallon Round','refill',0,'5-gal-round'),('ultra-pure:5-gal-slim','STN_007','5-Gallon Slim','refill',0,'5-gal-slim'),('ultra-pure:bottles','STN_007','Refill bottles','bottles',0,'bottles'),('ultra-pure:caps','STN_007','Sanitary caps','caps',0,'caps'),('ultra-pure:seals','STN_007','Bottle seals','seals',0,'seals'),('waterpol:5-gal-round','STN_008','5-Gallon Round','refill',0,'5-gal-round'),('waterpol:5-gal-slim','STN_008','5-Gallon Slim','refill',0,'5-gal-slim'),('waterpol:bottles','STN_008','Refill bottles','bottles',0,'bottles'),('waterpol:caps','STN_008','Sanitary caps','caps',0,'caps'),('waterpol:seals','STN_008','Bottle seals','seals',0,'seals');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `promotion`
--

DROP TABLE IF EXISTS `promotion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `promotion` (
  `id` char(36) NOT NULL,
  `owner_id` char(36) DEFAULT NULL,
  `code` varchar(100) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `value` decimal(10,2) DEFAULT NULL,
  `expires_at` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `owner_id` (`owner_id`),
  CONSTRAINT `promotion_ibfk_1` FOREIGN KEY (`owner_id`) REFERENCES `station_owner` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promotion`
--

LOCK TABLES `promotion` WRITE;
/*!40000 ALTER TABLE `promotion` DISABLE KEYS */;
INSERT INTO `promotion` VALUES ('promo-free-delivery','OWN_002','FREE-DELIVERY','delivery',0.00,'2026-11-26'),('promo-returning','OWN_002','RETURNING-CUSTOMER','percentage',10.00,'2026-11-26');
/*!40000 ALTER TABLE `promotion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reward`
--

DROP TABLE IF EXISTS `reward`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reward` (
  `id` char(36) NOT NULL,
  `owner_id` char(36) DEFAULT NULL,
  `name` varchar(190) DEFAULT NULL,
  `reward_description` text DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `code` varchar(100) DEFAULT NULL,
  `points_cost` int(11) DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `owner_id` (`owner_id`),
  CONSTRAINT `reward_ibfk_1` FOREIGN KEY (`owner_id`) REFERENCES `station_owner` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reward`
--

LOCK TABLES `reward` WRITE;
/*!40000 ALTER TABLE `reward` DISABLE KEYS */;
INSERT INTO `reward` VALUES ('rew-30-off',NULL,'P30 Refill Voucher','P30 off your next refill order.','active','AQUA30OFF',100,'Discount'),('rew-70-off',NULL,'P70 Refill Voucher (2 Free Slim Refills)','P70 off any refill order of 2 or more containers.','active','AQUA70FREE',200,'Discount'),('rew-caps',NULL,'5x Sanitary Container Caps & Seal Kit','Sanitary caps and seals for five containers.','active','FREE-CAPS5',150,'Merchandise'),('rew-tumbler',NULL,'AquaTracker 750ml Stainless Insulated Tumbler','Insulated AquaTracker tumbler.','active','CLAIM-TUMBLER',500,'Merchandise');
/*!40000 ALTER TABLE `reward` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staff`
--

DROP TABLE IF EXISTS `staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staff` (
  `id` char(36) NOT NULL,
  `user_id` char(36) DEFAULT NULL,
  `station_id` char(36) DEFAULT NULL,
  `approved_by` char(36) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `station_id` (`station_id`),
  KEY `approved_by` (`approved_by`),
  CONSTRAINT `staff_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `staff_ibfk_2` FOREIGN KEY (`station_id`) REFERENCES `station` (`id`),
  CONSTRAINT `staff_ibfk_3` FOREIGN KEY (`approved_by`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff`
--

LOCK TABLES `staff` WRITE;
/*!40000 ALTER TABLE `staff` DISABLE KEYS */;
INSERT INTO `staff` VALUES ('1b653025-71a8-4c7a-870a-3585edf995e6','USR_015','STN_002','USR_010','active'),('25e08e48-d905-42c5-ac41-959f7597081f','USR_022','STN_012','USR_023','active'),('2c437a87-eb5f-48b2-b8e7-2ad85306a889','USR_024','STN_002','USR_010','active'),('stf-demo-001','USR_011','STN_002','USR_010','active');
/*!40000 ALTER TABLE `staff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `station`
--

DROP TABLE IF EXISTS `station`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `station` (
  `id` char(36) NOT NULL,
  `owner_id` char(36) NOT NULL,
  `name` varchar(190) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `lat` decimal(11,10) NOT NULL,
  `lng` decimal(16,12) NOT NULL,
  `operating_hours` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`operating_hours`)),
  `status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_station_owner` (`owner_id`),
  CONSTRAINT `fk_station_owner` FOREIGN KEY (`owner_id`) REFERENCES `station_owner` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `station`
--

LOCK TABLES `station` WRITE;
/*!40000 ALTER TABLE `station` DISABLE KEYS */;
INSERT INTO `station` VALUES ('STN_001','OWN_001','Aqua\'Ter SMN Water Refilling Station','Beside DXPR Radio, San Jose District, Pagadian City',7.8191000000,123.441200000000,NULL,'open'),('STN_002','OWN_002','ClearSpring Water Hub','45 Sabellano St',7.8273300000,123.444185000000,'{\"hours\":\"7am-9pm\"}','open'),('STN_003','OWN_001','PG Aquamaster Water Refilling Station','Purok Makugihon, Brgy. Bulatok, Pagadian City',7.8198000000,123.429700000000,NULL,'open'),('STN_004','OWN_002','PH2O Water Refilling Station','Warlito Pulmones St, Santiago District, Pagadian City',7.8362000000,123.426400000000,NULL,'open'),('STN_005','OWN_001','AquaWorld','',7.8290000000,123.439000000000,'{\"hours\": \"Mon-Sat 7:30 AM-5:00 PM\"}','open'),('STN_006','OWN_003','ClearSpring Water Hub','',7.8300000000,123.440000000000,'{\"hours\": \"Mon-Sat 7:30 AM-5:00 PM\"}','open'),('STN_007','OWN_001','Ultra Pure Water Refilling Station','Purok Bakhaw A, Brgy. Kawit, Pagadian City',7.8312000000,123.443700000000,NULL,'open'),('STN_008','OWN_002','Waterpol Water Refilling Station','Purok Pagang, Brgy. Kawit, Pagadian City',7.8347000000,123.448100000000,NULL,'open'),('STN_009','OWN_004','ClearSpring Water Hub','',7.8320000000,123.442000000000,'{\"hours\":\"Mon-Sat 7:30 AM-5:00 PM\",\"contact\":\"\"}','open'),('STN_010','OWN_005','AQUAWATER Refilling Station','',7.8280000000,123.438000000000,'{\"hours\":\"Mon-Sat 7:30 AM-5:00 PM\",\"contact\":\"\"}','open'),('STN_011','OWN_006','H2O Water Refilling Station','',7.8330000000,123.445000000000,'{\"hours\":\"Mon-Sat 7:30 AM-5:00 PM\",\"contact\":\"\"}','open'),('STN_012','OWN_007','Tubig Refilling Station','',0.0000000000,0.000000000000,'{\"hours\":\"Mon-Sat 7:30 AM-5:00 PM\",\"contact\":\"\"}','open'),('STN_ALKA','OWN_002','Alka Water Refilling Station','Zone 11, Alta Tierra Subdivision, Tiguma, Pagadian City',7.8405800000,123.463360000000,NULL,'open');
/*!40000 ALTER TABLE `station` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `station_owner`
--

DROP TABLE IF EXISTS `station_owner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `station_owner` (
  `id` char(36) NOT NULL,
  `user_id` char(36) DEFAULT NULL,
  `owner_name` varchar(190) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `station_owner_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `station_owner`
--

LOCK TABLES `station_owner` WRITE;
/*!40000 ALTER TABLE `station_owner` DISABLE KEYS */;
INSERT INTO `station_owner` VALUES ('OWN_001','USR_008','Jin'),('OWN_002','USR_010','Joan Dela Cruz'),('OWN_003','USR_007','Ken Dela Torre'),('OWN_004','USR_012','Percy Valiente'),('OWN_005','USR_013','Dave Valiente'),('OWN_006','USR_014','Finn'),('OWN_007','USR_023','Jewel');
/*!40000 ALTER TABLE `station_owner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscription`
--

DROP TABLE IF EXISTS `subscription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subscription` (
  `id` char(36) NOT NULL,
  `customer_id` char(36) DEFAULT NULL,
  `plan_id` char(36) DEFAULT NULL,
  `next_delivery` date DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `meta` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`meta`)),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`),
  KEY `plan_id` (`plan_id`),
  CONSTRAINT `subscription_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`),
  CONSTRAINT `subscription_ibfk_2` FOREIGN KEY (`plan_id`) REFERENCES `subscription_plan` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscription`
--

LOCK TABLES `subscription` WRITE;
/*!40000 ALTER TABLE `subscription` DISABLE KEYS */;
/*!40000 ALTER TABLE `subscription` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscription_plan`
--

DROP TABLE IF EXISTS `subscription_plan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subscription_plan` (
  `id` char(36) NOT NULL,
  `station_id` char(36) DEFAULT NULL,
  `name` varchar(190) DEFAULT NULL,
  `gallons_included` int(11) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `frequency` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `station_id` (`station_id`),
  CONSTRAINT `subscription_plan_ibfk_1` FOREIGN KEY (`station_id`) REFERENCES `station` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscription_plan`
--

LOCK TABLES `subscription_plan` WRITE;
/*!40000 ALTER TABLE `subscription_plan` DISABLE KEYS */;
INSERT INTO `subscription_plan` VALUES ('plan:aquater','STN_001','Recurring Refill Plan',1,25.00,'monthly','active'),('plan:drink-refill','STN_002','Recurring Refill Plan',1,35.00,'monthly','active'),('plan:pg-aquamaster','STN_003','Recurring Refill Plan',1,30.00,'monthly','active'),('plan:ph2o','STN_004','Recurring Refill Plan',1,30.00,'monthly','active'),('plan:ultra-pure','STN_007','Recurring Refill Plan',1,30.00,'monthly','active'),('plan:waterpol','STN_008','Recurring Refill Plan',1,35.00,'monthly','active');
/*!40000 ALTER TABLE `subscription_plan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` char(36) NOT NULL,
  `email` varchar(190) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` varchar(50) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `station` varchar(190) NOT NULL DEFAULT '',
  `station_id` varchar(64) NOT NULL DEFAULT '',
  `permissions` text DEFAULT NULL,
  `status` enum('active','pending','rejected') NOT NULL DEFAULT 'active',
  `email_verified` tinyint(1) NOT NULL DEFAULT 1,
  `auth_version` int(10) unsigned NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('USR_001','emannuelvillanuvaaaa@gmail.com','$2y$10$YHvolGIIK5xjxooPRBGmTu633Fu.i.QNmVv6QvItQxeKq6uk5Z33q','customer','Emmanuel','2026-10-27 15:28:46','Customer account','','[]','active',1,1),('USR_002','admin@test.com','$2y$10$X2IpsTx9A5i21LNA7sBmQu8oO0fjHTsCbQ31DGCevcnuslCXisYAm','admin','Administrator','2026-10-27 14:59:21','','','[]','active',1,1),('USR_003','kim@gmail.com','$2y$10$0aHIPPfT3orkUMyepTUan.sKD3K2P6acywGcj8OiA4G.dZvMfQcy.','staff','Kim Dela Cruz','2026-10-27 16:53:21','','','[\"orders\",\"inventory\",\"requests\"]','pending',1,1),('USR_004','kirstenvaliente120605@gmail.com','$2y$10$n8FXFdmP5Wcp3TmwTUAqJevH9jL9cBdXyZ4HrZM9jWL4DQSxObAQK','customer','Kirsten Valiente','2026-10-27 15:34:10','Customer account','','[]','active',1,1),('USR_005','emannuelvillanuvaaa@gmail.com','$2y$10$z6G2RfoNbNvr2YiNn8S6g.hef/QjHFNgBgJmzmSnWtlD4K4WPEtzK','customer','Hiroshi','2026-10-27 15:28:03','Customer account','','[]','active',1,1),('USR_006','emmanuel@gmail.com','$2y$10$IhTH0dUDozQOrLt38c84hOt0m.pzwKDfefqlJ.W8wjXnQbZgOc/Ky','customer','Emmanuel Geroche','2026-10-27 15:06:08','Customer account','','[]','active',1,1),('USR_007','ken@gmail.com','$2y$10$FNoIJpPUzpkuXGRx.oOUievPQ.LWyZrGxLmkplP/wRN6xMwNccDRy','owner','Ken Dela Torre','2026-10-28 07:29:57','ClearSpring Water Hub','STN_006','[]','active',1,1),('USR_008','jin@gmail.com','$2y$10$4hI8VTWlVVPuUSHz0tCzBepMhPjXQ8wNynVil1WF2MvFP30JziYse','owner','Jin','2026-10-27 16:54:14','AquaWorld','STN_005','[]','active',1,1),('USR_009','customer.demo@example.com','$2y$10$1Q1zx.t2fC.Q9mH6bvR0EeIAjGd3IvUblGcrHsQMpI.djqy3jAeOu','customer','Mia Santos','2026-10-27 15:00:25','','','[]','active',1,1),('USR_010','owner.demo@example.com','$2y$10$gUhqhqDO/KnteYld26Y.4erFWG0dt3LGITE.0nLfAotw/g9eTn7.2','owner','Joan Dela Cruz','2026-10-27 15:00:25','ClearSpring Water Hub','STN_002','[]','active',1,1),('USR_011','staff.demo@example.com','$2y$10$20j1Qp0T3X1QOo8l/fJfeuy3TjchR4v1icrcAR/JYeetbGb.IlEJG','staff','Staff Demo','2026-10-27 15:00:25','ClearSpring Water Hub','STN_002','[\"orders\",\"inventory\",\"requests\"]','active',1,1),('USR_012','percyvaliente@gmail.com','$2y$10$yokvYiHjckUnlEY4Ty2fP.o.28VE67f99VpSptoQJlKFyOft4qYAK','owner','Percy Valiente','2026-10-31 12:24:01','ClearSpring Water Hub','STN_009','[]','active',1,1),('USR_013','dave@gmail.com','$2y$10$8bBPI5wVBp15yBu40wsuTeZyIME0f85X3ra5eKlBJZHp0uEd0.YCy','owner','Dave Valiente','2026-10-31 12:39:29','AQUAWATER Refilling Station','STN_010','[]','active',1,1),('USR_014','finn@gmail.com','$2y$10$K5Yb5fO0cU7DsaXnZCgQYu00aakqtUl1C5pSbHPSy.iIrIjW.JvIK','owner','Finn','2026-10-31 13:06:28','H2O Water Refilling Station','STN_011','[]','active',1,1),('USR_015','new.staff.1793453232137@example.com','$2y$10$wVK2ZxgKnHHO6tLE8gRynuE9Pt/d/sOa24G2OtkDI6Rb8DBf/GE5.','staff','New Staff','2026-10-31 13:27:12','ClearSpring Water Hub','STN_002','[\"orders\",\"inventory\",\"requests\"]','active',1,1),('USR_016','iso.1793453233012@example.com','$2y$10$lODFw5h9YhlB1knOD7mtfe/ZTFmVKdqGGaRKZlM3gtR6jJikiyB..','customer','Iso User','2026-10-31 13:27:13','Customer account','','[]','active',1,1),('USR_017','klintizuki@gmail.com','$2y$10$k9qqG7Lhw3jjxeFSI5MKXO.ezdEmaArjJgVqtE6Su/UdV8fPR/UIS','customer','Klint Izuki','2026-11-02 09:26:38','Customer account','','[]','active',1,1),('USR_018','xcelvillarico@gmail.com','$2y$10$vIDLM11II5nfAG184FWUqu7qfDH2vCHeJ7v/zK0mYh5NoV5ioxDy.','customer','Xcel Villarico','2026-11-02 09:35:13','Customer account','','[]','active',1,1),('USR_019','kirstengwapa06@gmail.com','$2y$10$jaE67nvFrOU43YsrnFZW3eflDNxcis1Fei/UIZs/rTILX45.Cur2S','customer','Kirsten','2026-11-02 09:51:51','Customer account','','[]','active',1,1),('USR_020','villaricojerryson@gmail.com','$2y$10$UJo9SctlNnWwaXGW95j4T.P9iiAOABTDc1Vx1YQrfRzJSszY9nJeq','customer','Jerryson Villarico','2026-11-02 10:58:10','Customer account','','[]','active',1,2),('USR_021','geroche.v.e@gmail.com','$2y$10$O8YMakLdfgWP8X6xF6AfuOV27Ya5CGNS1rWgvgyuGMEBNYCOKTtLG','customer','Emmanuel','2026-11-02 11:05:26','Customer account','','[]','active',1,1),('USR_022','joangracep@gmail.com','$2y$10$0gY3VeR172XUNr4Q8uQO2OJmselQvICGL/Oso1mH39VjGN6W4IXsi','staff','Joan Patalinghug','2026-11-02 11:13:11','Tubig Refilling Station','STN_012','[\"orders\",\"inventory\",\"requests\"]','active',1,1),('USR_023','kim@example.com','$2y$10$0itGny8KDGgsCmQ3V5nMqOJ9J82mvVPSy7VwX11KnnMPC8RbGw5yq','owner','Jewel','2026-11-02 11:15:06','Tubig Refilling Station','STN_012','[]','active',1,1),('USR_024','new.staff.1794279274128@example.com','$2y$10$sRkO7JlVRnMlldApaLxgiuUtkaXcAgRj7QgGDxAQcWzXCAbl.h9WO','staff','New Staff','2026-11-10 02:54:34','ClearSpring Water Hub','STN_002','[\"orders\",\"inventory\",\"requests\"]','active',1,1),('USR_025','iso.1794279275008@example.com','$2y$10$0oF/.jBG/McXZqNu9C91YeLtY8obGhDtkVsmF5uyKlkYBaNqezqp6','customer','Iso User','2026-11-10 02:54:35','Customer account','','[]','active',1,1),('USR_026','nicsxy1225@gmail.com','$2y$10$CYqQiOa/xsQc4Zl7cJKOR.LA8cIsFbSJc8QI42zAZbVBQHRHk/zra','customer','Nicole Jansol','2026-11-11 05:55:39','Customer account','','[]','active',1,1),('USR_027','navalunagracyann2@gmail.com','$2y$10$f2PtvUWv/MB6xalTWe0e8eBdyd10dqDdX/ZpJcWsRDbbyGe.UdvU6','customer','Gracy','2026-11-11 05:59:35','Customer account','','[]','active',1,1),('USR_028','davedaydayvaliente20@gmail.com','$2y$10$0.VbnwoL.pHULm/9YxZEAOXmt4iAevUjzBzor9FW323fnbTjIFj3O','customer','Dave Valiente','2026-11-11 06:18:37','Customer account','','[]','active',1,1),('USR_029','xxtheonlyonexx2@gmail.com','$2y$10$TiAFflOZ2q6wRG45xn5x6OrdAnaxT.NWOelTROLHe/UE6hyvfFOWO','customer','kenzy esmering','2026-11-11 06:20:20','Customer account','','[]','active',1,1),('USR_030','labastillajewel@gmail.com','$2y$10$Vsz.oKS5WFfKv3nuZVyete1DGixQT56JmdE9age6sxpPLnHZAYVSK','customer','Kim Labastilla','2026-11-11 06:38:44','Customer account','','[]','active',1,1),('USR_031','klintrant@gmail.com','$2y$10$1pkVmgWlksnneRiLTW0e.ee4I4rRcSyl9OfG/IUwkZmcHTk/nUbP6','customer','Klint','2026-11-13 01:48:49','Customer account','','[]','active',1,1),('USR_035','percyvaliente500@gmail.com','$2y$10$.UzvXDsrlfVSYT.Q/NuRV.1VcxjcRPMJSy0OqpBZvevtyxJAMwsE.','customer','Percy Villarico Valiente','2026-11-14 04:05:48','Customer account','','[]','active',1,1);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'aquatracker'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-16 12:08:41

﻿-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: aquatracker
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `station`
--

DROP TABLE IF EXISTS `station`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `station` (
  `id` char(36) NOT NULL,
  `owner_id` char(36) NOT NULL,
  `name` varchar(190) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `lat` decimal(11,10) NOT NULL,
  `lng` decimal(16,12) NOT NULL,
  `operating_hours` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`operating_hours`)),
  `status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_station_owner` (`owner_id`),
  CONSTRAINT `fk_station_owner` FOREIGN KEY (`owner_id`) REFERENCES `station_owner` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `station`
--

LOCK TABLES `station` WRITE;
/*!40000 ALTER TABLE `station` DISABLE KEYS */;
INSERT INTO `station` VALUES ('STN_001','OWN_001','Aqua\'Ter SMN Water Refilling Station','Beside DXPR Radio, San Jose District, Pagadian City',0.0000000000,0.000000000000,NULL,'open'),('STN_002','OWN_002','DRINK n\' REFILL Purified Water Refilling Station','45 Sabellano St, San Jose District, Pagadian City',7.8273302000,123.444185259400,'{\"hours\": \"Mon-Sat 7:30 AM-5:00 PM\"}','open'),('STN_003','OWN_001','PG Aquamaster Water Refilling Station','Purok Makugihon, Brgy. Bulatok, Pagadian City',0.0000000000,0.000000000000,NULL,'open'),('STN_004','OWN_002','PH2O Water Refilling Station','Warlito Pulmones St, Santiago District, Pagadian City',0.0000000000,0.000000000000,NULL,'open'),('STN_005','OWN_001','AquaWorld','',0.0000000000,0.000000000000,'{\"hours\": \"Mon-Sat 7:30 AM-5:00 PM\"}','open'),('STN_006','OWN_003','ClearSpring Water Hub','',0.0000000000,0.000000000000,'{\"hours\": \"Mon-Sat 7:30 AM-5:00 PM\"}','open'),('STN_007','OWN_001','Ultra Pure Water Refilling Station','Purok Bakhaw A, Brgy. Kawit, Pagadian City',0.0000000000,0.000000000000,NULL,'open'),('STN_008','OWN_002','Waterpol Water Refilling Station','Purok Pagang, Brgy. Kawit, Pagadian City',0.0000000000,0.000000000000,NULL,'open'),('STN_009','OWN_004','ClearSpring Water Hub','',0.0000000000,0.000000000000,'{\"hours\":\"Mon-Sat 7:30 AM-5:00 PM\",\"contact\":\"\"}','open'),('STN_010','OWN_005','AQUAWATER Refilling Station','',0.0000000000,0.000000000000,'{\"hours\":\"Mon-Sat 7:30 AM-5:00 PM\",\"contact\":\"\"}','open'),('STN_011','OWN_006','H2O Water Refilling Station','',0.0000000000,0.000000000000,'{\"hours\":\"Mon-Sat 7:30 AM-5:00 PM\",\"contact\":\"\"}','open');
/*!40000 ALTER TABLE `station` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-31 21:18:56

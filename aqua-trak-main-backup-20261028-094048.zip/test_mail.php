<?php
/** Local Gmail SMTP diagnostic. Never expose this endpoint to remote clients. */

declare(strict_types=1);

$remoteAddress = $_SERVER['REMOTE_ADDR'] ?? '';
if (!in_array($remoteAddress, ['127.0.0.1', '::1'], true)) {
    http_response_code(403);
    exit('Forbidden: this SMTP diagnostic is available only from localhost.');
}

header('Content-Type: text/plain; charset=utf-8');

$recipient = filter_input(INPUT_GET, 'email', FILTER_VALIDATE_EMAIL);
if (!is_string($recipient) || $recipient === '') {
    http_response_code(400);
    exit('Provide a valid recipient address, for example ?email=test@example.com');
}

$autoload = __DIR__ . '/vendor/autoload.php';
if (!is_file($autoload)) {
    http_response_code(500);
    exit('PHPMailer is missing. Run composer install from the project root.');
}
require_once $autoload;

$gmailAddress = trim((string) getenv('AQUA_GMAIL_ADDRESS'));
// PASTE YOUR 16-LETTER GMAIL APP PASSWORD HERE: use AQUA_GMAIL_APP_PASSWORD in Apache instead of hard-coding it here.
$rawAppPassword = (string) getenv('AQUA_GMAIL_APP_PASSWORD');
$appPassword = preg_replace('/\s+/', '', $rawAppPassword);

// Safe environment inspection: ?env=1 shows lengths but never the SMTP secret.
if (($_GET['env'] ?? '') === '1') {
    echo "<h3>DEBUG INFO:</h3>\n";
    echo 'Email being used: ' . ($gmailAddress !== '' ? $gmailAddress : '[not set]') . "\n";
    echo 'Password set: ' . ($rawAppPassword !== '' ? 'yes' : 'no') . "\n";
    echo 'Password length (Apache value): ' . strlen($rawAppPassword) . "\n";
    echo 'Password length (whitespace removed): ' . strlen($appPassword) . "\n";
    echo "Password: [REDACTED]\n";
    exit;
}

if ($gmailAddress === '' || $appPassword === '') {
    http_response_code(503);
    exit("Gmail SMTP is not configured. Set AQUA_GMAIL_ADDRESS and AQUA_GMAIL_APP_PASSWORD in the Apache vhost, then restart Apache.\n");
}

$mail = new \PHPMailer\PHPMailer\PHPMailer(false);
$mail->isSMTP();
$mail->Host = 'smtp.gmail.com';
$mail->SMTPAuth = true;
$mail->Username = $gmailAddress;
$mail->Password = $appPassword;
$mail->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;
$mail->Port = 465;
// Keep TLS certificate verification enabled; disabling it can expose the
// Gmail App Password to an intercepted SMTP connection and does not fix 535.
$mail->SMTPDebug = 2;

// Keep the SMTP dialogue visible while redacting AUTH and base64 credentials.
$redactingAuth = false;
$mail->Debugoutput = static function (string $message, int $level) use (&$redactingAuth): void {
    if (stripos($message, 'CLIENT -> SERVER: AUTH') !== false) {
        $redactingAuth = true;
        $message = preg_replace('/(CLIENT -> SERVER: AUTH)\s+.*$/i', '$1 [REDACTED]', $message) ?? $message;
    } elseif ($redactingAuth && stripos($message, 'CLIENT -> SERVER:') !== false) {
        $message = preg_replace('/CLIENT -> SERVER:.*$/i', 'CLIENT -> SERVER: [REDACTED AUTH DATA]', $message) ?? $message;
    } elseif ($redactingAuth && preg_match('/SERVER -> CLIENT:\s*(235|535)\b/i', $message)) {
        $redactingAuth = false;
    }
    echo htmlspecialchars($message, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    flush();
};

$mail->CharSet = \PHPMailer\PHPMailer\PHPMailer::CHARSET_UTF8;
$mail->setFrom($gmailAddress, 'AquaTracker SMTP Test');
$mail->addAddress($recipient);
$mail->Subject = 'AquaTracker Gmail SMTP test';
$mail->Body = 'This is a direct SMTP test from AquaTracker.';
$mail->AltBody = 'This is a direct SMTP test from AquaTracker.';

echo "Testing smtp.gmail.com:465 with SMTPS; AUTH payloads are redacted.\n";
echo 'SMTP Username: ' . htmlspecialchars($mail->Username, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . "\n";
if (!$mail->send()) {
    echo "Error: " . $mail->ErrorInfo . "\n";
} else {
    echo "Success! Email sent.\n";
}

<?php
// Apache serves frontend/ as its document root; keep the requested diagnostic
// in the project root and forward this URL to that guarded implementation.
require dirname(__DIR__) . '/test_mail.php';

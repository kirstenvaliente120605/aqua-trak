﻿/**
 * Owner data facade backed by the PHP/ERD API.
 *
 * Customer requests have no ERD table, so that read-only demo inbox remains in
 * localStorage. Every other section reads and writes shared database rows.
 */

(function (global) {
  "use strict";

  const keys = global.AquaCommon.STORE_KEYS;
  const common = global.AquaCommon;
  let stationId = null;

  function setOwner(user) {
    stationId = user.stationId || null;

    if (!stationId) {
      const stations = common.read(keys.STATIONS, []);
      const station = stations.find(item =>
        (user.userId && item.ownerId === user.userId) ||
        (user.station && item.name === user.station)
      );
      stationId = station ? station.id : null;
    }
  }

  function localRequests() {
    return common.read(keys.REQUESTS, []).filter(item => item.stationId === stationId);
  }

  async function fetchBusinessStats() {
    return common.api("/api/owner/overview");
  }

  async function fetchOrders() {
    const data = await common.api("/api/owner/orders");
    return Array.isArray(data.orders) ? data.orders : [];
  }

  async function updateOrderStatus(orderId, newStatus) {
    const data = await common.api(`/api/owner/orders/${encodeURIComponent(orderId)}`, {
      method: "PATCH",
      body: JSON.stringify({ status: newStatus }),
    });
    return data.order;
  }

  async function fetchInventory() {
    const data = await common.api("/api/owner/inventory");
    return data.inventory || {};
  }

  async function fetchPricing() {
    const data = await common.api("/api/owner/pricing");
    return data.pricing || {};
  }

  async function updatePricing(pricingData) {
    const data = await common.api("/api/owner/pricing", {
      method: "POST",
      body: JSON.stringify({ pricing: pricingData }),
    });
    return data;
  }

  async function fetchCustomers() {
    const data = await common.api("/api/owner/customers");
    return Array.isArray(data.customers) ? data.customers : [];
  }

  async function fetchSettings() {
    const data = await common.api("/api/owner/settings");
    return data.settings || {};
  }

  async function updateSettings(settingsData) {
    const data = await common.api("/api/owner/settings", {
      method: "POST",
      body: JSON.stringify({ settings: settingsData }),
    });
    return data.settings;
  }

  async function fetchStaffApprovals() {
    const data = await common.api("/api/staff-approvals");
    return Array.isArray(data.approvals) ? data.approvals : [];
  }

  async function fetchStaff() {
    const data = await common.api("/api/owner/staff");
    return Array.isArray(data.staff) ? data.staff : [];
  }

  async function decideStaffApproval(id, decision) {
    if (!["approve", "reject"].includes(decision)) {
      throw new Error("Invalid approval decision.");
    }
    return common.api(`/api/staff-approvals/${encodeURIComponent(id)}`, {
      method: "POST",
      body: JSON.stringify({ decision }),
    });
  }

  async function fetchSubscriptions() {
    const data = await common.api("/api/owner/subscriptions");
    return Array.isArray(data.subscriptions) ? data.subscriptions : [];
  }

  async function fetchPromotions() {
    const data = await common.api("/api/owner/promotions");
    return Array.isArray(data.promotions) ? data.promotions : [];
  }

  async function createPromotion(promotionData) {
    const data = await common.api("/api/owner/promotions", {
      method: "POST",
      body: JSON.stringify(promotionData),
    });
    return data.promotion;
  }

  async function fetchCustomersRequests() {
    return localRequests();
  }

  const AquaOwner = {
    setOwner,
    fetchBusinessStats,
    fetchOrders,
    updateOrderStatus,
    fetchInventory,
    fetchPricing,
    updatePricing,
    fetchCustomers,
    fetchSettings,
    updateSettings,
    fetchStaffApprovals,
    fetchStaff,
    decideStaffApproval,
    fetchSubscriptions,
    fetchPromotions,
    createPromotion,
    fetchCustomersRequests,
  };

  global.AquaOwner = AquaOwner;

  // Keep AquaCommon available for owner-dashboard.js compatibility.
  global.AquaCommon = {
    ...global.AquaCommon,
    fetchOrders: global.AquaCommon.fetchOrders,
  };
})(typeof window !== "undefined" ? window : this);


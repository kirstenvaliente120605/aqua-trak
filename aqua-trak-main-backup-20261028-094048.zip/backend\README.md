﻿# AquaTracker PHP backend

The active application is the PHP API in `backend/api`, served with the frontend through the root `router.php` or XAMPP Apache. The legacy Node backend under `backend/src` is not used by the PHP setup.

## Run with XAMPP

1. Start XAMPP MySQL/MariaDB and Apache.
2. From the repository root, open `http://localhost:8080`.
3. The authoritative database schema is `create_erd.sql`; demo records are seeded with `C:\xampp\php\php.exe seed_erd.php`.

For PHP's built-in server, run `C:\xampp\php\php.exe -S localhost:8080 -t . router.php` from the repository root. The API uses same-origin routes such as `/api/auth/me`, `/api/stations`, and `/api/orders`.

Database credentials are in `backend/api/config.php`: localhost, port 3306, database `aquatracker`, user `root`, empty password.

## Welcome email (Gmail SMTP)

PHPMailer is installed with Composer. After checkout, run `composer install` from the project root. In the active XAMPP virtual host at `C:\xampp\apache\conf\extra\httpd-aquatracker.conf`, add these directives inside the `<VirtualHost *:8080>` block and replace the placeholders. Use a Google App Password, not your Gmail account password:

```apache
SetEnv AQUA_GMAIL_ADDRESS "your-account@gmail.com"
SetEnv AQUA_GMAIL_APP_PASSWORD "your-16-character-app-password"
```

Restart Apache after editing the vhost. The App Password is read only from the Apache environment and is not stored in the repository. If SMTP is unavailable or unconfigured, registration still succeeds and the mail error is written to the PHP error log.

After configuring those values, open `http://localhost:8080/test_mail.php?email=your-recipient@example.com` to view the SMTP diagnostics. The endpoint accepts localhost requests only and redacts SMTP AUTH credentials from the debug transcript.

## Sign-in accounts

- Admin: `admin@test.com` / `password123` at `/auth/admin/login`
- Customer: `customer.demo@example.com` / `CustomerDemo123!`
- Owner: `owner.demo@example.com` / `OwnerDemo123!`
- Staff: `staff.demo@example.com` / `StaffDemo123!`

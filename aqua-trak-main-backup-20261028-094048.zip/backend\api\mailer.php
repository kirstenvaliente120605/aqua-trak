<?php
/** Gmail SMTP welcome email helper. Credentials come from the Apache environment. */

declare(strict_types=1);

namespace AquaTracker;

use PHPMailer\PHPMailer\PHPMailer;

/** Send the post-registration greeting to the account owner. */
function sendWelcomeEmail(string $userEmail, string $userName): void
{
    $composerAutoload = dirname(__DIR__, 2) . DIRECTORY_SEPARATOR . 'vendor' . DIRECTORY_SEPARATOR . 'autoload.php';
    if (!is_file($composerAutoload)) {
        throw new \RuntimeException('PHPMailer is missing. Run composer install from the project root.');
    }
    require_once $composerAutoload;

    $gmailAddress = trim((string) getenv('AQUA_GMAIL_ADDRESS'));
    $appPassword = preg_replace('/\s+/', '', (string) getenv('AQUA_GMAIL_APP_PASSWORD'));
    if ($gmailAddress === '' || $appPassword === '') {
        throw new \RuntimeException('Gmail SMTP is not configured in the Apache environment.');
    }

    $mail = new PHPMailer(false);
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = $gmailAddress;
    $mail->Password = $appPassword;
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;
    $mail->CharSet = PHPMailer::CHARSET_UTF8;

    $mail->setFrom($gmailAddress, 'AquaTracker');
    $mail->addAddress($userEmail, $userName);
    $mail->isHTML(true);
    $mail->Subject = 'Welcome to AquaTracker';
    $safeName = htmlspecialchars($userName, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    $mail->Body = "<h1>Welcome to AquaTracker, {$safeName}!</h1><p>Your account is ready. Find a nearby water station and place your first refill order whenever you need it.</p><p>Thank you for joining us,<br>The AquaTracker team</p>";
    $mail->AltBody = "Welcome to AquaTracker, {$userName}! Your account is ready. Find a nearby water station and place your first refill order whenever you need it.\n\nThank you for joining us,\nThe AquaTracker team";
    if (!$mail->send()) {
        error_log($mail->ErrorInfo);
        throw new \RuntimeException($mail->ErrorInfo ?: 'Gmail SMTP rejected the welcome email.');
    }
}
